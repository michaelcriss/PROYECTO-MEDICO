﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BusinessLogic
{
    public class Aviones
    {
        public int Id { get; set; }
        public string? Codigo { get; set; }
        public string? Tipo { get; set; }
        public int? IDBase { get; set; }


       public DataTable ListarBase()
        {
            try
            {
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "ListarBaseMantenimiento";
                cmd.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                dt = dbAcess.Consultar(cmd);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ListarAvion()
        {
            try
            {
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "ListarAvius";
                cmd.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                dt = dbAcess.Consultar(cmd);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Add()
        {
            try
            {
                string sql;
                sql = " Insert into avion (CODIGO, TIPO, IDBASE) Values(@CODIGO,@TIPO,@IDBASE) ";
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@CODIGO", Codigo);
                cmd.Parameters.AddWithValue("@TIPO", Tipo);
                cmd.Parameters.AddWithValue("@IDBASE", IDBase);
               ;
                dbAcess.Ejecutar(cmd);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataTable GetById()
        {
            try
            {
                string sql;
                sql = " Select IDAVION, CODIGO, TIPO, BaseMantenimiento.BASE from avion " +
                    "inner join BaseMantenimiento on avion.IDBASE = BaseMantenimiento.IDBASE" +
                    " Where IDAVION=@IDAVION";
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@IDAVION", Id);
                DataTable dt = new DataTable();
                dt = dbAcess.Consultar(cmd);
 

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Edit()
        {
            try
            {
                string sql;
                sql = " Update avion set CODIGO=@CODIGO, TIPO=@TIPO, IDBASE=@IDBASE Where IDAVION=@IDAVION";
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@IDAVION", Id);
                cmd.Parameters.AddWithValue("@CODIGO", Codigo);
                cmd.Parameters.AddWithValue("@TIPO", Tipo);
                cmd.Parameters.AddWithValue("@IDBASE", IDBase);

                dbAcess.Ejecutar(cmd);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Delete()
        {
            try
            {
                string sql;
                sql = " Delete from avion Where IDAVION=@IDAVION ";
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@IDAVION", Id);
                dbAcess.Ejecutar(cmd);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

}
