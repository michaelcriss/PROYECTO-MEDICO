﻿using DataAccess;
using System.Data;
using System.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace BusinessLogic
{
    public class Vuelo
    {
        public DataTable ListarMiembro()
        {
            try
            {
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "ListarMiembros";
                cmd.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                dt = dbAcess.Consultar(cmd);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ListarPiloto()
        {
            try
            {
;               DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "ListarPiloto";
                cmd.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                dt = dbAcess.Consultar(cmd);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable ListarAvion()
        {
            try
            {
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "ListarAvionVuelos";
                cmd.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                dt = dbAcess.Consultar(cmd);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataTable ListarVuelo()
        {
            try
            {
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "ListarVuelos";
                cmd.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                dt = dbAcess.Consultar(cmd);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int Id { get; set; }
        public string? NumVuelo { get; set; }
        public string? Origen { get; set; }
        public string? Destino { get; set; }
        public string? Fecha { get; set; }
        public int ? IDMiembro { get; set; }
        public int? IDPiloto { get; set; }
        public int? IDAvion { get; set; }

        public bool Add()
        {
            try
            {
                string sql;
                sql = " Insert into vuelos (NUMVUELO,ORIGEN,DESTINO,FECHA,IDPILOTO,IDMIEMBROS, IDAVION) Values(@NUMVUELO,@ORIGEN,@DESTINO,@FECHA,@IDPILOTO,@IDMIEMBROS, @IDAVION) ";
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@NUMVUELO", NumVuelo);
                cmd.Parameters.AddWithValue("@ORIGEN", Origen);
                cmd.Parameters.AddWithValue("@DESTINO", Destino);
                cmd.Parameters.AddWithValue("@FECHA", Fecha);
                cmd.Parameters.AddWithValue("@IDPILOTO", IDPiloto);
                cmd.Parameters.AddWithValue("@IDMIEMBROS", IDMiembro);
                cmd.Parameters.AddWithValue("@IDAVION", IDAvion);
                dbAcess.Ejecutar(cmd);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetById()
        {
            try
            {
                string sql;
                sql = " Select IDVUELOS, NUMVUELO, ORIGEN, DESTINO, FECHA, piloto.NOMBRE as PILOTO,  MiembrosTripulacion.NOMBRE as MIEMBRO, avion.TIPO as AVIÓN from vuelos " +
                    "inner join piloto on vuelos.IDPILOTO = piloto.IDPILOTO " +
                    "inner join MiembrosTripulacion on vuelos.IDMIEMBROS = MIEMBROSTRIPULACION.IDMIEMBROS " +
                    "inner join avion on vuelos.IDAVION = avion.IDAVION " +
                    "Where IDVUELOS=@IDVUELOS";
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@IDVUELOS", Id);
                DataTable dt = new DataTable();
                dt = dbAcess.Consultar(cmd);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Edit()
        {
            try
            {
                string sql;
                sql = " Update vuelos set NUMVUELO=@NUMVUELO, ORIGEN=@ORIGEN, DESTINO=@DESTINO, FECHA=@FECHA, IDPILOTO=IDPILOTO, IDMIEMBROS=@IDMIEMBROS, IDAVION=IDAVION Where IDVUELOS=@IDVUELOS";
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@IDVUELOS", Id);
                cmd.Parameters.AddWithValue("@NUMVUELO", NumVuelo);
                cmd.Parameters.AddWithValue("@ORIGEN", Origen);
                cmd.Parameters.AddWithValue("@DESTINO", Destino);
                cmd.Parameters.AddWithValue("@FECHA", Fecha);
                cmd.Parameters.AddWithValue("@IDPILOTO", IDPiloto);
                cmd.Parameters.AddWithValue("@IDAVION", IDAvion);
                cmd.Parameters.AddWithValue("@IDMIEMBROS", IDMiembro);

                dbAcess.Ejecutar(cmd);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool Delete()
        {
            try
            {
                string sql;
                sql = " Delete from vuelos Where IDVUELOS=@IDVUELOS ";
                DA dbAcess = new DA();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@IDVUELOS", Id);
                dbAcess.Ejecutar(cmd);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}