﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            abrirFormHijo(new Vuelos());
        }

        private void Main_Load(object sender, EventArgs e)
        {
        }

        private Form formActual = null;
        public void abrirFormHijo(object formHijo)
        {
            if (formActual != null)
            {
                this.middlePanel.Controls.Remove(formActual);
            }

            Form fH = formHijo as Form;
            fH.TopLevel = false;
            fH.Dock = DockStyle.Fill;
            this.middlePanel.Controls.Add(fH);
            this.middlePanel.Tag = fH;
            fH.BringToFront();
            fH.Show();
            formActual = fH as Form;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            abrirFormHijo(new Avion());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            abrirFormHijo(new BaseMantenimiento());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            abrirFormHijo(new Form1());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            abrirFormHijo(new MiembrosTripulacion());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
