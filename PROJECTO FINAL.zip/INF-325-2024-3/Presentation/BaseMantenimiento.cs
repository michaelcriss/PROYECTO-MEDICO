﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class BaseMantenimiento : Form
    {
        public BaseMantenimiento()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                Base bases = new Base();
                bases.BaseMantenimiento = txtBase.Text;
                bases.Ubicacion = txtUbicacion.Text;


                if (bases.Add())
                {
                    dataGridView1.DataSource = bases.Get();
                    MessageBox.Show("Los datos fueron registrado correctamente");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConsultar_Click_1(object sender, EventArgs e)
        {
            try
            {
                Base bases = new Base();
                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        bases.Id = id;
                        dataGridView1.DataSource = bases.GetById();
                        return;
                    }
                }
                else
                {
                    dataGridView1.DataSource = bases.Get();
                    return;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEditar_Click_1(object sender, EventArgs e)
        {
            try
            {
                Base bases = new Base();

                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        bases.Id = id;
                        bases.BaseMantenimiento = txtBase.Text;
                        bases.Ubicacion = txtUbicacion.Text;

                        if (bases.Edit())
                        {
                            dataGridView1.DataSource = bases.Get();
                            MessageBox.Show("Los datos fueron actualizados correctamente");
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                Base bases = new Base(); ;

                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        bases.Id = id;
                        if (bases.Delete())
                        {
                            dataGridView1.DataSource = bases.Get();
                            MessageBox.Show("Los datos fueron eliminados correctamente");
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
    
}
