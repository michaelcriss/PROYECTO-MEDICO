﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Presentation
{
    public partial class Avion : Form
    {
        public Avion()
        {
            InitializeComponent();
        }
        private void Avion_Load(object sender, EventArgs e)
        {
            ListarBaseMantenimiento();
            
        }
        private void ListarBaseMantenimiento()
        {
            Aviones avios = new Aviones();
            cmbBase.DataSource = avios.ListarBase();
            cmbBase.DisplayMember = "Base";
            cmbBase.ValueMember = "IDBASE";
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {

            try
            {
                Aviones avios = new Aviones();
                avios.Codigo = txtCodigo.Text;
                avios.Tipo = txtTipo.Text;
                avios.IDBase = Convert.ToInt32(cmbBase.SelectedValue);

                if (avios.Add())
                {
                    dataGridView1.DataSource = avios.ListarAvion();
                    MessageBox.Show("Los datos fueron registrado correctamente");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Aviones avios = new Aviones();
                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        avios.Id = id;
                        dataGridView1.DataSource = avios.GetById();

                        return;
                    }
                }
                else
                {
                    dataGridView1.DataSource = avios.ListarAvion();
                    return;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {

            try
            {
                Aviones avios = new Aviones();

                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        avios.Id = id;
                        avios.Codigo = txtCodigo.Text;
                        avios.Tipo = txtTipo.Text;
                        avios.IDBase = Convert.ToInt32(cmbBase.SelectedValue);
                        if (avios.Edit())
                        {
                            dataGridView1.DataSource = avios.ListarAvion();
                            MessageBox.Show("Los datos fueron actualizados correctamente");
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            try
            {
                Aviones avios = new Aviones();

                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        avios.Id = id;
                        if (avios.Delete())
                        {
                            dataGridView1.DataSource = avios.ListarAvion();
                            MessageBox.Show("Los datos fueron eliminados correctamente");
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}

