﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class Vuelos : Form
    {
        public Vuelos()
        {
            InitializeComponent();
        }

        private void Vuelos_Load(object sender, EventArgs e)
        {
            ListarMiembros();
            ListarAvion();
            ListarPiloto();
        }

        private void ListarMiembros()
        {
            Vuelo vuelos = new Vuelo();
            cmbMiembro.DataSource = vuelos.ListarMiembro();
            cmbMiembro.DisplayMember = "NOMBRE";
            cmbMiembro.ValueMember = "IDMIEMBROS";

        }

        private void ListarPiloto()
        {
            Vuelo vuelos = new Vuelo();
            cmbPiloto.DataSource = vuelos.ListarPiloto();
            cmbPiloto.DisplayMember = "NOMBRE";
            cmbPiloto.ValueMember = "IDPILOTO";

        }

        private void ListarAvion()
        {
            Vuelo vuelos = new Vuelo();
            cmbAvion.DataSource = vuelos.ListarAvion();
            cmbAvion.DisplayMember = "TIPO";
            cmbAvion.ValueMember = "IDAVION";

        }


        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                Vuelo vuelos = new Vuelo();
                vuelos.NumVuelo = txtNumVuelo.Text;
                vuelos.Origen = txtOrigen.Text;
                vuelos.Destino = txtDestino.Text;
                vuelos.Fecha = Convert.ToString(dtpFecha.Value.Date);
                vuelos.IDPiloto = Convert.ToInt32(cmbPiloto.SelectedValue);
                vuelos.IDMiembro = Convert.ToInt32(cmbMiembro.SelectedValue);
                vuelos.IDAvion = Convert.ToInt32(cmbAvion.SelectedValue);


                if (vuelos.Add())
                {

                    dataGridView1.DataSource = vuelos.ListarVuelo();
                    MessageBox.Show("Los datos fueron registrado correctamente");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Vuelo vuelos = new Vuelo();
                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        vuelos.Id = id;
                        dataGridView1.DataSource = vuelos.GetById();

                        return;
                    }
                }
                else
                {
                    dataGridView1.DataSource = vuelos.ListarVuelo();
                    return;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                Vuelo vuelos = new Vuelo();

                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        vuelos.Id = id;
                        vuelos.NumVuelo = txtNumVuelo.Text;
                        vuelos.Origen = txtOrigen.Text;
                        vuelos.Destino = txtOrigen.Text;
                        vuelos.Fecha = Convert.ToString(dtpFecha.Value.Date);
                        vuelos.IDPiloto = Convert.ToInt32(cmbPiloto.SelectedValue);
                        vuelos.IDMiembro = Convert.ToInt32(cmbMiembro.SelectedValue);
                        vuelos.IDAvion = Convert.ToInt32(cmbAvion.SelectedValue);
                        if (vuelos.Edit())
                        {
                            dataGridView1.DataSource = vuelos.ListarVuelo();
                            MessageBox.Show("Los datos fueron actualizados correctamente");
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            try
            {
                Vuelo vuelos = new Vuelo();

                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        vuelos.Id = id;
                        if (vuelos.Delete())
                        {
                            dataGridView1.DataSource = vuelos.ListarVuelo();
                            MessageBox.Show("Los datos fueron eliminados correctamente");
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

