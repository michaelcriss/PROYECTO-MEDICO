﻿using BusinessLogic;

namespace Presentation
{
    public partial class MiembrosTripulacion : Form
    {
        public MiembrosTripulacion()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                Tripulacion miembrosTripulacion = new Tripulacion();
                miembrosTripulacion.Codigo = txtCodigo.Text;
                miembrosTripulacion.Nombre = txtNombre.Text;


                if (miembrosTripulacion.Add())
                {
                    dataGridView1.DataSource = miembrosTripulacion.Get();
                    MessageBox.Show("Los datos fueron registrado correctamente");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                Tripulacion miembrosTripulacion = new Tripulacion();
                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        miembrosTripulacion.Id = id;
                        dataGridView1.DataSource = miembrosTripulacion.GetById();
                        return;
                    }
                }
                else
                {
                    dataGridView1.DataSource = miembrosTripulacion.Get();
                    return;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                Tripulacion miembrosTripulacion = new Tripulacion();

                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        miembrosTripulacion.Id = id;
                        miembrosTripulacion.Codigo = txtCodigo.Text;
                        miembrosTripulacion.Nombre = txtNombre.Text;

                        if (miembrosTripulacion.Edit())
                        {
                            dataGridView1.DataSource = miembrosTripulacion.Get();
                            MessageBox.Show("Los datos fueron actualizados correctamente");
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            try
            {

                Tripulacion miembrosTripulacion = new Tripulacion();

                if (!string.IsNullOrEmpty(txtId.Text))
                {
                    int id = int.Parse(txtId.Text);
                    if (id > 0)
                    {
                        miembrosTripulacion.Id = id;
                        if (miembrosTripulacion.Delete())
                        {
                            dataGridView1.DataSource = miembrosTripulacion.Get();
                            MessageBox.Show("Los datos fueron eliminados correctamente");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
